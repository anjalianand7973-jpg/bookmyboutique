BookMyBoutique Demo

Files: index.html

Open index.html in Chrome to test. Use dummy customer details only.
Features: booking list, status, advance/balance calculation, CSV export, WhatsApp message draft, and a demo enquiry robot that answers only from prices configured in the app.

Important limits:
- Data is stored only in the same browser/device (localStorage); it does not sync between customers/business owners.
- The enquiry robot is rule-based demo logic, not a connected AI model and not WhatsApp automation.
- No login, cloud database, backups, or payment processing.
- Before real customer use or charging money, add authentication, a secure shared database, privacy controls, and test thoroughly.
